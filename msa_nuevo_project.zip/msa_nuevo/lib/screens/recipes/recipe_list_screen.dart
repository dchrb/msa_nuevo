
import 'package:flutter/material.dart';

class RecipeListScreen extends StatelessWidget {
  const RecipeListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Aquí se mostrará la lista de recetas.'),
    );
  }
}
