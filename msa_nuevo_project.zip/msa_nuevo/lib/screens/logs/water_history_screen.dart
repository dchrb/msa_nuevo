import 'package:flutter/material.dart';

class WaterHistoryScreen extends StatelessWidget {
  const WaterHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Aquí se mostrará el historial de ingesta de agua.'),
    );
  }
}
